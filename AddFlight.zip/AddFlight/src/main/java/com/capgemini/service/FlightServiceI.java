package com.capgemini.service;



import com.capgemini.entity.Flight;

public interface FlightServiceI {

	String addFlight(Flight flight);

	


}
